import { useState } from 'react';
import Ionicons from '@expo/vector-icons/Ionicons';
import { ActivityIndicator,Pressable,ScrollView,StyleSheet,useWindowDimensions,View } from 'react-native';
import { LanguageSwitch, Text, TextInput } from '../../../i18n';
import { SafeAreaView } from 'react-native-safe-area-context';
import { router } from 'expo-router'; import { ApiError,api,establishSession } from '../../../api'; import { theme } from '../../../theme';
const periods = [
  ['monthly', 'Mensal'],
  ['quarterly', 'Trimestral'],
  ['semiannual', 'Semestral'],
  ['annual', 'Anual −20%'],
] as const;

const plans = [
  {
    id: 'starter',
    name: 'Starter',
    prices: {
      monthly: 'R$ 49,90',
      quarterly: 'R$ 134,73',
      semiannual: 'R$ 254,49',
      annual: 'R$ 479,04',
    },
    detail: '30 clientes · 10 orçamentos/mês',
  },
  {
    id: 'pro',
    name: 'Pro',
    prices: {
      monthly: 'R$ 99,90',
      quarterly: 'R$ 269,73',
      semiannual: 'R$ 509,49',
      annual: 'R$ 959,04',
    },
    detail: '150 clientes · PDF personalizado',
  },
  {
    id: 'business',
    name: 'Business',
    prices: {
      monthly: 'R$ 179,90',
      quarterly: 'R$ 485,73',
      semiannual: 'R$ 917,49',
      annual: 'R$ 1.727,04',
    },
    detail: 'Ilimitado · Kanban e BI',
  },
];
type BillingPeriod=(typeof periods)[number][0];
type RegisterSession=Parameters<typeof establishSession>[0];
const errorMessage=(error:unknown)=>error instanceof ApiError||error instanceof Error?error.message:'Erro inesperado';
export default function Register(){const wide=useWindowDimensions().width>=900;const[company,setCompany]=useState(''),[name,setName]=useState(''),[phone,setPhone]=useState(''),[email,setEmail]=useState(''),[password,setPassword]=useState(''),[plan,setPlan]=useState('pro'),[period,setPeriod]=useState<BillingPeriod>('monthly'),[busy,setBusy]=useState(false),[error,setError]=useState('');async function submit(){try{setBusy(true);setError('');const result=await api<RegisterSession>('/auth/register',{method:'POST',body:JSON.stringify({company,name,phone,email,password,plan,period})});establishSession(result);router.replace('/home')}catch(e:unknown){setError(errorMessage(e))}finally{setBusy(false)}}return <SafeAreaView style={s.page}><View style={s.language}><LanguageSwitch compact/></View><View style={[s.brandSide,!wide&&s.brandSideMobile]}><View style={s.logo}><View style={s.mark}><Text style={s.markText}>L</Text></View><Text style={s.logoText}>LuviePro</Text></View>{wide&&<><Text style={s.hero}>Comece a profissionalizar seu negócio hoje.</Text><Text style={s.heroSub}>Teste todos os recursos durante 14 dias. Sem cartão de crédito e sem compromisso.</Text><View style={s.benefits}>{['Orçamentos profissionais em segundos','Gestão completa de clientes','Projetos e etapas organizados','Sua marca em cada proposta'].map(text=><View key={text} style={s.benefit}><Ionicons name="checkmark-circle" size={18} color={theme.gold}/><Text style={s.benefitText}>{text}</Text></View>)}</View></>}</View><ScrollView style={s.formSide} contentContainerStyle={[s.formContent,!wide&&{paddingTop:110}]}><Pressable onPress={()=>router.back()} style={s.back}><Ionicons name="arrow-back" size={17} color={theme.green2}/><Text style={s.backText}>Voltar ao login</Text></Pressable><Text style={s.title}>Crie sua conta grátis</Text><Text style={s.subtitle}>Escolha o plano e aproveite 14 dias de teste.</Text><View style={s.periods}>{periods.map(([value,label])=><Pressable key={value} onPress={()=>setPeriod(value)} style={[s.period,period===value&&s.periodOn]}><Text style={[s.periodText,period===value&&s.periodTextOn]}>{label}</Text></Pressable>)}</View><View style={s.planGrid}>{plans.map(item=><Pressable key={item.id} onPress={()=>setPlan(item.id)} style={[s.plan,plan===item.id&&s.planOn]}><View style={s.planHead}><Text style={s.planName}>{item.name}</Text>{plan===item.id&&<Ionicons name="checkmark-circle" size={18} color={theme.green2}/>}</View><Text style={s.planPrice}>{item.prices[period]}<Text style={s.month}>{period==='monthly'?'/mês':'/período'}</Text></Text><Text style={s.planDetail}>{item.detail}</Text></Pressable>)}</View><View style={s.fields}><Field label="NOME DA EMPRESA *" value={company} change={setCompany}/><Field label="SEU NOME *" value={name} change={setName}/><Field label="TELEFONE / WHATSAPP" value={phone} change={setPhone}/><Field label="E-MAIL *" value={email} change={setEmail}/><Field label="SENHA *" value={password} change={setPassword} password/></View>{error?<Text style={s.error}>⚠ {error}</Text>:null}<Pressable disabled={busy} onPress={submit} style={[s.submit,busy&&{opacity:.6}]}>{busy?<ActivityIndicator color={theme.g900}/>:<Text style={s.submitText}>Começar teste grátis de 14 dias</Text>}</Pressable><Text style={s.terms}>Ao criar sua conta, você concorda com os termos de uso e política de privacidade.</Text></ScrollView></SafeAreaView>}
function Field({label,value,change,password}:{label:string;value:string;change:(value:string)=>void;password?:boolean}){return <View style={s.field}><Text style={s.label}>{label}</Text><TextInput value={value} onChangeText={change} secureTextEntry={password} autoCapitalize={label.includes('E-MAIL')?'none':'sentences'} style={s.input}/></View>}
const s=StyleSheet.create({language:{position:'absolute',top:18,right:18,zIndex:20},page:{flex:1,flexDirection:'row',backgroundColor:theme.cream},brandSide:{width:'38%',backgroundColor:theme.g800,padding:42},brandSideMobile:{position:'absolute',top:0,left:0,right:0,width:'100%',height:86,padding:20,zIndex:2},logo:{flexDirection:'row',alignItems:'center',gap:10},mark:{width:38,height:38,borderRadius:11,backgroundColor:theme.gold,alignItems:'center',justifyContent:'center'},markText:{fontFamily:'serif',fontSize:21,fontWeight:'800',color:theme.g900},logoText:{fontFamily:'serif',fontSize:22,fontWeight:'700',color:theme.white},hero:{fontFamily:'serif',fontSize:32,lineHeight:39,fontWeight:'700',color:theme.white,marginTop:68,maxWidth:390},heroSub:{fontSize:13,lineHeight:21,color:'rgba(255,255,255,.55)',marginTop:16,maxWidth:370},benefits:{marginTop:38,gap:16},benefit:{flexDirection:'row',alignItems:'center',gap:10},benefitText:{fontSize:13,color:'rgba(255,255,255,.72)'},formSide:{flex:1},formContent:{padding:36,paddingTop:28,maxWidth:980,width:'100%',alignSelf:'center'},back:{flexDirection:'row',alignItems:'center',gap:6,marginBottom:20},backText:{fontSize:12,fontWeight:'800',color:theme.green2},title:{fontFamily:'serif',fontSize:27,fontWeight:'700',color:theme.ink},subtitle:{fontSize:13,color:theme.muted,marginTop:5,marginBottom:20},planGrid:{flexDirection:'row',flexWrap:'wrap',gap:10},plan:{minWidth:170,flex:1,borderWidth:1,borderColor:theme.border,borderRadius:12,padding:13,backgroundColor:theme.white},planOn:{borderColor:theme.green2,backgroundColor:theme.green50},planHead:{flexDirection:'row',justifyContent:'space-between'},planName:{fontFamily:'serif',fontSize:15,fontWeight:'700',color:theme.ink},planPrice:{fontSize:13,fontWeight:'800',color:theme.gold,marginTop:8},month:{fontSize:11,fontWeight:'500',color:theme.muted},planDetail:{fontSize:11,color:theme.muted,marginTop:5},fields:{flexDirection:'row',flexWrap:'wrap',gap:11,marginTop:20},field:{minWidth:230,flex:1},label:{fontSize:11,fontWeight:'800',letterSpacing:.8,color:theme.muted,marginBottom:6},input:{height:42,borderWidth:1,borderColor:theme.border,borderRadius:9,paddingHorizontal:11,fontSize:13,color:theme.ink,backgroundColor:theme.white},error:{fontSize:12,color:theme.danger,marginTop:13},submit:{height:46,borderRadius:10,backgroundColor:theme.gold,alignItems:'center',justifyContent:'center',marginTop:18},submitText:{fontSize:13,fontWeight:'900',color:theme.g900},terms:{fontSize:11,color:theme.muted,textAlign:'center',marginTop:11},periods:{flexDirection:'row',flexWrap:'wrap',gap:6,marginBottom:14},period:{borderWidth:1,borderColor:theme.border,borderRadius:18,paddingHorizontal:11,paddingVertical:7},periodOn:{backgroundColor:theme.gold,borderColor:theme.gold},periodText:{fontSize:11,fontWeight:'700',color:theme.muted},periodTextOn:{color:theme.g900}});
